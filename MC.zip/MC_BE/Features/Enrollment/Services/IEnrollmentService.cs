using MC_BE.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace MC_BE.Shared.Services.Interfaces;

public interface IEnrollmentService
{
    Task<ApiResponse<EnrollmentDto>> EnrollCourseAsync(int learnerId, int courseId);
    Task<ApiResponse<List<EnrollmentDto>>> GetMyEnrollmentsAsync(int learnerId);
    Task<ApiResponse<bool>> CancelPendingEnrollmentAsync(int learnerId, int enrollmentId);
    Task<ApiResponse<bool>> RevokeEnrollmentByAdminAsync(int enrollmentId, RevokeEnrollmentRequest request);
    Task<bool> HasActiveAccessAsync(int learnerId, int courseId);
    Task<ApiResponse<List<CourseEnrolledStudentDto>>> GetCourseStudentsAsync(
    int instructorId,
    int courseId
);
}