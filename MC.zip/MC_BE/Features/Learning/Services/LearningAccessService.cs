using MC_BE.Core.Enums;
using MC_BE.Features.Learning.Services.Interfaces;
using MC_BE.Shared.Data;
using Microsoft.EntityFrameworkCore;

namespace MC_BE.Features.Learning.Services;

// Read-only access decisions: never change progress, attempts, or course content.
public sealed class LearningAccessService : ILearningAccessService
{
    private readonly SmartMcDbContext _db;
    public LearningAccessService(SmartMcDbContext db) => _db = db;

    private sealed record LessonNode(int Id, int? ModuleId, int Order, bool Preview);
    private sealed record QuizNode(int Id, int? LessonId, int? ModuleId, QuizPurpose Purpose, QuizStatus Status);

    private async Task<(List<LessonNode> Lessons, List<QuizNode> Quizzes, HashSet<int> Passed, List<int> Modules)> LoadAsync(int learnerId, int courseId)
    {
        var moduleOrder = await _db.Modules.AsNoTracking().Where(x => x.CourseId == courseId)
            .OrderBy(x => x.OrderIndex).ThenBy(x => x.ModuleId).Select(x => x.ModuleId).ToListAsync();
        var lessons = await _db.Lessons.AsNoTracking().Where(x => x.CourseId == courseId && x.Status == LessonStatus.ACTIVE)
            .Select(x => new LessonNode(x.LessonId, x.ModuleId, x.OrderIndex, x.IsPreview)).ToListAsync();
        var quizzes = await _db.Quizzes.AsNoTracking().Where(x => x.CourseId == courseId ||
            (x.LessonId.HasValue && _db.Lessons.Any(l => l.LessonId == x.LessonId && l.CourseId == courseId)) ||
            (x.ModuleId.HasValue && _db.Modules.Any(m => m.ModuleId == x.ModuleId && m.CourseId == courseId)))
            .Select(x => new QuizNode(x.QuizId, x.LessonId, x.ModuleId, x.Purpose, x.Status)).ToListAsync();
        var ids = quizzes.Select(q => q.Id).ToList();
        var passed = await _db.QuizAttempts.AsNoTracking().Where(a => a.UserId == learnerId && ids.Contains(a.QuizId) && a.ResultStatus == QuizAttemptStatus.PASSED)
            .Select(a => a.QuizId).Distinct().ToListAsync();
        return (lessons, quizzes, passed.ToHashSet(), moduleOrder);
    }

    private static List<LessonNode> Ordered(List<LessonNode> lessons, List<int> modules) => lessons
        .OrderBy(l => l.ModuleId.HasValue ? (modules.IndexOf(l.ModuleId.Value) < 0 ? int.MaxValue - 1 : modules.IndexOf(l.ModuleId.Value)) : int.MaxValue)
        .ThenBy(l => l.Order).ThenBy(l => l.Id).ToList();

    private static string? LessonLock(LessonNode target, List<LessonNode> ordered, List<QuizNode> quizzes, HashSet<int> passed, List<int> modules)
    {
        var index = ordered.FindIndex(l => l.Id == target.Id);
        if (index < 0) return "Lesson is not active.";
        if (index == 0) return null;
        var previous = ordered[index - 1];
        // Each preceding lesson must have at least one ACTIVE practice quiz, and ALL its practice quizzes must be passed.
        var practices = quizzes.Where(q => q.Purpose == QuizPurpose.PRACTICE && q.LessonId == previous.Id).ToList();
        if (practices.Count == 0) return $"Previous lesson {previous.Id} has no practice quiz configured.";
        if (practices.Any(q => !passed.Contains(q.Id))) return $"Pass the practice quiz of lesson {previous.Id} first.";
        if (previous.ModuleId != target.ModuleId && previous.ModuleId.HasValue)
        {
            var previousModule = previous.ModuleId.Value;
            foreach (var l in ordered.Where(x => x.ModuleId == previousModule))
            {
                var required = quizzes.Where(q => q.Purpose == QuizPurpose.PRACTICE && q.LessonId == l.Id).ToList();
                if (required.Count == 0 || required.Any(q => !passed.Contains(q.Id)))
                    return "Pass all practice quizzes in the previous chapter first.";
            }
            var assessments = quizzes.Where(q => q.Purpose == QuizPurpose.CHAPTER_ASSESSMENT && q.ModuleId == previousModule).ToList();
            if (assessments.Count == 0 || assessments.Any(q => q.Status != QuizStatus.ACTIVE || !passed.Contains(q.Id)))
                return "Pass the previous chapter assessment first.";
        }
        return null;
    }

    public async Task<Dictionary<int, string?>> GetLessonLocksAsync(int learnerId, int courseId)
    {
        var data = await LoadAsync(learnerId, courseId);
        var ordered = Ordered(data.Lessons, data.Modules);
        var result = new Dictionary<int, string?>();
        foreach (var lesson in ordered)
        {
            // A lock anywhere earlier in the sequence keeps all subsequent lessons locked.
            var priorLock = ordered.Take(ordered.FindIndex(x => x.Id == lesson.Id))
                .Select(x => result.GetValueOrDefault(x.Id)).FirstOrDefault(x => x != null);
            result[lesson.Id] = priorLock ?? LessonLock(lesson, ordered, data.Quizzes, data.Passed, data.Modules);
        }
        return result;
    }

    public async Task<(bool Allowed, string? Reason)> CheckLessonAsync(int learnerId, int lessonId)
    {
        var lesson = await _db.Lessons.AsNoTracking().Where(x => x.LessonId == lessonId).Select(x => new { x.CourseId, x.IsPreview }).FirstOrDefaultAsync();
        if (lesson == null) return (false, "Lesson not found.");
        var enrolled = await _db.Enrollments.AsNoTracking().AnyAsync(e => e.LearnerId == learnerId && e.CourseId == lesson.CourseId && e.Status != "PENDING_PAYMENT");
        if (!enrolled) return (false, "Course enrollment required.");
        var locks = await GetLessonLocksAsync(learnerId, lesson.CourseId);
        if (!locks.TryGetValue(lessonId, out var reason)) return (false, "Lesson is not active.");
        return (reason == null, reason);
    }

    public async Task<(bool Allowed, string? Reason)> CheckQuizAsync(int learnerId, int quizId)
    {
        var quiz = await _db.Quizzes.AsNoTracking().Where(x => x.QuizId == quizId).Select(x => new { x.CourseId, x.LessonId, x.ModuleId, x.Purpose, x.Status, x.AvailableFrom, x.AvailableUntil }).FirstOrDefaultAsync();
        if (quiz == null || quiz.Status != QuizStatus.ACTIVE) return (false, "Quiz is unavailable.");
        var now = DateTime.UtcNow;
        if (quiz.AvailableFrom.HasValue && now < quiz.AvailableFrom.Value || quiz.AvailableUntil.HasValue && now >= quiz.AvailableUntil.Value)
            return (false, "Quiz is outside its availability window.");
        var courseId = quiz.CourseId;
        if (!courseId.HasValue && quiz.LessonId.HasValue) courseId = await _db.Lessons.Where(x => x.LessonId == quiz.LessonId).Select(x => (int?)x.CourseId).FirstOrDefaultAsync();
        if (!courseId.HasValue && quiz.ModuleId.HasValue) courseId = await _db.Modules.Where(x => x.ModuleId == quiz.ModuleId).Select(x => (int?)x.CourseId).FirstOrDefaultAsync();
        if (!courseId.HasValue) return (false, "Quiz must belong to a course.");
        var enrolled = await _db.Enrollments.AsNoTracking().AnyAsync(e => e.LearnerId == learnerId && e.CourseId == courseId && e.Status != "PENDING_PAYMENT");
        if (!enrolled) return (false, "Course enrollment required.");
        var data = await LoadAsync(learnerId, courseId.Value);
        var ordered = Ordered(data.Lessons, data.Modules);
        var locks = await GetLessonLocksAsync(learnerId, courseId.Value);
        if (quiz.Purpose == QuizPurpose.PRACTICE)
        {
            if (!quiz.LessonId.HasValue) return (false, "Practice quiz must belong to a lesson.");
            return locks.TryGetValue(quiz.LessonId.Value, out var reason) && reason == null ? (true, null) : (false, reason ?? "Lesson is locked.");
        }
        if (quiz.Purpose == QuizPurpose.DAILY_PRACTICE)
        {
            if (!quiz.LessonId.HasValue) return (true, null);
            return locks.TryGetValue(quiz.LessonId.Value, out var dailyLessonReason) && dailyLessonReason == null
                ? (true, null)
                : (false, dailyLessonReason ?? "Lesson is locked.");
        }
        if (quiz.Purpose == QuizPurpose.CHAPTER_ASSESSMENT)
        {
            if (!quiz.ModuleId.HasValue) return (false, "Chapter assessment must belong to a chapter.");
            var chapterLessons = ordered.Where(x => x.ModuleId == quiz.ModuleId).ToList();
            if (chapterLessons.Count == 0) return (false, "Chapter has no lessons.");
            foreach (var l in chapterLessons)
            {
                if (locks.GetValueOrDefault(l.Id) != null) return (false, "Complete the chapter in order first.");
                var required = data.Quizzes.Where(q => q.Purpose == QuizPurpose.PRACTICE && q.LessonId == l.Id).ToList();
                if (required.Count == 0 || required.Any(q => !data.Passed.Contains(q.Id))) return (false, "Pass every practice quiz in this chapter first.");
            }
            return (true, null);
        }
        if (quiz.Purpose == QuizPurpose.FINAL_ASSESSMENT)
        {
            var result = await CheckCourseGatesAsync(learnerId, courseId.Value, requireFinal: false);
            return result;
        }
        return (false, "Unsupported quiz purpose.");
    }

    private async Task<(bool Allowed, string? Reason)> CheckCourseGatesAsync(int learnerId, int courseId, bool requireFinal)
    {
        var data = await LoadAsync(learnerId, courseId);
        var ordered = Ordered(data.Lessons, data.Modules);
        if (ordered.Count == 0) return (false, "Course has no active lessons.");
        var locks = await GetLessonLocksAsync(learnerId, courseId);
        if (locks.Values.Any(reason => reason != null)) return (false, "Some lessons are still locked.");
        foreach (var l in ordered)
        {
            var required = data.Quizzes.Where(q => q.Purpose == QuizPurpose.PRACTICE && q.LessonId == l.Id).ToList();
            if (required.Count == 0 || required.Any(q => !data.Passed.Contains(q.Id))) return (false, "Pass all lesson practice quizzes first.");
        }
        foreach (var moduleId in data.Modules.Where(id => ordered.Any(l => l.ModuleId == id)))
        {
            var required = data.Quizzes.Where(q => q.Purpose == QuizPurpose.CHAPTER_ASSESSMENT && q.ModuleId == moduleId).ToList();
            if (required.Count == 0 || required.Any(q => !data.Passed.Contains(q.Id))) return (false, "Pass all chapter assessments first.");
        }
        if (requireFinal)
        {
            var required = data.Quizzes.Where(q => q.Purpose == QuizPurpose.FINAL_ASSESSMENT).ToList();
            if (required.Count == 0 || required.Any(q => !data.Passed.Contains(q.Id))) return (false, "Pass the final assessment first.");
        }
        return (true, null);
    }

    public async Task<(bool Allowed, string? Reason)> CheckCertificateAsync(int learnerId, int courseId)
    {
        var gates = await CheckCourseGatesAsync(learnerId, courseId, requireFinal: true);
        if (!gates.Allowed) return gates;
        var lessonIds = await _db.Lessons.AsNoTracking().Where(x => x.CourseId == courseId && x.Status == LessonStatus.ACTIVE).Select(x => x.LessonId).ToListAsync();
        var enrollmentId = await _db.Enrollments.AsNoTracking().Where(e => e.CourseId == courseId && e.LearnerId == learnerId && e.Status != "PENDING_PAYMENT").Select(e => (int?)e.EnrollmentId).FirstOrDefaultAsync();
        if (!enrollmentId.HasValue) return (false, "Active enrollment required.");
        var completed = await _db.LessonProgresses.AsNoTracking().Where(x => x.EnrollmentId == enrollmentId && lessonIds.Contains(x.LessonId) && (x.IsCompleted || x.Status == LessonProgressStatus.COMPLETED)).Select(x => x.LessonId).Distinct().CountAsync();
        return completed == lessonIds.Count ? (true, null) : (false, "Complete every lesson before receiving a certificate.");
    }
}
